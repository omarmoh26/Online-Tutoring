<?php 
include "TutorMenu.php";
$conn = new mysqli("localhost", "root", "", "online_tutoringdb");

if(isset($_POST['submit'])){
	$i=$_SESSION['ID'];
	
	if(!empty($_FILES['myfile'])){
	$dir='../images/';
	$fileName=$_FILES['myfile']['name'];
	move_uploaded_file($_FILES['myfile']['tmp_name'],$dir.$fileName);
	}
	else{
		$fileName=$_SESSION["Image"];
	}
	$type=$_SESSION['usertype'];
	$sql="update user set Image='$fileName' where UserID='$i'";
		$result=mysqli_query($conn,$sql);
		if(!$result){
			die("Unable to excute query");
		}
		else{
			$_SESSION["Image"]=$fileName;
			header("Location:TutorHome.php");
		}
}

?>
<link rel="stylesheet" type="text/css" href ="EditPicTutor.css">

<form action='' method='POST' enctype="multipart/form-data" onsubmit='return validate(this)'>
<input type='file' name='myfile' id="file" onchange="return fileValidation()"><br>

<input type= 'submit'  name= 'submit'  value= 'Submit' ><br>
<input type="button" value="Cancel" onclick="cancel()"></input>
</form>
<head>
	<script>
		function cancel() {
            window.location.href = "TutorHome.php";
        }
		function validatePic(field){
			if(field=='')
				return 'Choose a new Picture \n';
			else
				return '';
		}
		function validate(form){
			fail='';
			fail+=validatePic(form.myfile.value);
			if(fail=='')
				return true;
			else{
				alert(fail);
				return false;
			}
		}

		function fileValidation() {
            var fileInput = 
                document.getElementById('file');
              
            var filePath = fileInput.value;
            var allowedExtensions = 
                    /(\.jpg|\.jpeg|\.png|\.gif)$/i;
              
            if (!allowedExtensions.exec(filePath)) {
                alert('Invalid file type');
                fileInput.value = '';
                return false;
            } 
            else 
            {
                if (fileInput.files && fileInput.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        document.getElementById(
                            'imagePreview').innerHTML = 
                            '<img src="' + e.target.result
                            + '"/>';
                    };
                      
                    reader.readAsDataURL(fileInput.files[0]);
                }
            }
        }

	</script>
</head>
