<html>
<?php 
include "TutorHome.php";
echo "<h2 style='right:10px;'> Add The new Course</h2>";
    if(isset($_POST['submit'])){
            
		if(!empty($_FILES['myfile'])){
			$dir='../images/';
			$fileName=$_FILES['myfile']['name'];
			move_uploaded_file($_FILES['myfile']['tmp_name'],$dir.$fileName);
			}
			else{
				$fileName="";
			}
        $c=$_POST['code'];
        $n=$_POST['name'];
        $d=$_POST['duration'];
        $p=$_POST['price'];
		$t=$_SESSION['ID'];
		$a="no";
        
        $sanitizedCode=filter_var($c,FILTER_SANITIZE_STRING);
        $sanitizedName=filter_var($n,FILTER_SANITIZE_STRING);
        $sanitizedDuration=filter_var($d,FILTER_SANITIZE_NUMBER_INT);
        $sanitizedPrice=filter_var($p,FILTER_SANITIZE_NUMBER_INT);
        
        $conn = new mysqli("localhost","root","","online_tutoringdb");

            if($conn->connect_error)
                die("cannot connect database");

            if (filter_var($sanitizedDuration, FILTER_VALIDATE_INT) && filter_var($sanitizedPrice, FILTER_VALIDATE_INT)){

                $sql="INSERT INTO courses (courseCode, courseName,courseDuration, coursePrice, TutorID, Approved , Image ) 
                        VALUES ('$sanitizedCode','$sanitizedName','$sanitizedDuration','$sanitizedPrice','$t','$a','$fileName')";
                $result=mysqli_query($conn,$sql);
                
                if(!$result){
                    die("Unable to excute query");
                }
                else{
                    header("Location:CoursesTutor.php");
                }
            }
            else{
                echo "Please Enter the data in the correct format";
            }
            $conn -> close();
    }
?>

<form action="" method="post"  enctype='multipart/form-data' onsubmit='return validate(this)'>
    Course Code: <input type=text name=code >
    Course Name: <input type=text name=name >
    Course Duration: <input type=text name=duration>
    Course Price:<input type=text name=price ><br>
	Choose Picture:<input type='file' name='myfile' id="file" onchange="return fileValidation()">
    <!-- Choose Course Material:<input type= "file" name="upload" id="material" > -->
    <input type="submit" value="Add" name="submit" >
    <input type="button" value="Cancel" onclick="cancel()"></input>
</form>
<head>
	<script>
        function cancel() {
            window.location.href = "AdminCourses.php";
        }
		function validateCode(field){
			if(field=='')
				return 'No Course Code was entered \n';
			else
				return '';
		}
		function validateName(field){
			if(field=='')
				return 'No Course Name was entered \n';
			else
				return '';
		}
		function validateDuration(field){
			if(field=='')
				return 'No Course Duration was entered \n';
			else
				return '';
		}
		function validatePrice(field){
			if(field=='')
				return 'No Course Price was entered \n';
			else
				return '';
		}
		
		function validate(form){
			fail='';
			fail+=validateCode(form.code.value);
			fail+=validateName(form.name.value);
			fail+=validateDuration(form.duration.value);
			fail+=validatePrice(form.price.value);
			if(fail==''){
				return true;	
			}
				
			else{
				alert(fail);
				return false;
			}
		}

		function fileValidation() {
            var fileInput = 
                document.getElementById('file');
              
            var filePath = fileInput.value;
            var allowedExtensions = 
                    /(\.jpg|\.jpeg|\.png|\.gif)$/i;
              
            if (!allowedExtensions.exec(filePath)) {
                alert('Invalid file type');
                fileInput.value = '';
                return false;
            } 
            else 
            {
                if (fileInput.files && fileInput.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        document.getElementById(
                            'imagePreview').innerHTML = 
                            '<img src="' + e.target.result
                            + '"/>';
                    };
                      
                    reader.readAsDataURL(fileInput.files[0]);
                }
            }
        }
	</script>
</head>
</html>