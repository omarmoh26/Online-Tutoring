<html>
<?php
include "AuditorMenu.php";
?>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  /* color: blue; */
  /* overflow: hidden; */
  font-size: 20px;
}

li a {
  display: block;
  color: darkred;
  padding: 14px 16px;
  font-family: 'Oswald', sans-serif;
  /* text-decoration: none; */
}

li a:hover {
	background-color: gold;
	color: navy;
}

    
</style>

<ul>
	<li><a href='EditNameAuditor.php'> Edit Name </a></li>
	<li><a href='EditPicAuditor.php'> Edit Picture </a></li>
	<li><a href='EditPassAuditor.php'> Edit Password </a></li>
	<li><a href='DeleteAccount.php'> Delete </a></li>
	<li><a href='../SignOut.php'> SignOut </a> </li>
</ul>
</html>