<link rel="stylesheet" type="text/css" href ="DeleteAccount.css">

<?php
	include "AuditorMenu.php";
	echo "<n class='n'>".$_SESSION['Name']."</n>";
	echo "<br> </n> <n2 class='n2'> are you sure you want to delete this account?</n2>";
?>

	<div class="wrapper fadeInDown">
		<form action="" method="post">
			<input class="n3" type="submit" value="DELETE" name="yes">
			<input class="n4" type="submit" value="Cancel" name="no">
		</form>
	</div>	

<?php
	if(isset($_POST['yes'])){
		$conn = new mysqli("localhost", "root", "", "online_tutoringdb");
		$sql="delete from user where UserID =".$_SESSION['ID'];
		$result=mysqli_query($conn,$sql);
		if($result)
		{
			session_destroy();
			header("Location:../home.php");
		}
		else
		{
			echo $sql;
		}
	}
	if(isset($_POST['no'])){
		header("Location:AuditorHome.php");
	}
?>