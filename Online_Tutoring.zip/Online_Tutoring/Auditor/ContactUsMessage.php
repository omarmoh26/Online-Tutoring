<?php
include "../links.html";
include "AuditorMenu.php";
$conn = new mysqli("localhost", "root", "", "online_tutoringdb");

?>
<table class="table table-striped">
<tr><div style = "margin: 10;">
    <th>    <h4 style = "color: black;display:inline;">Name</h4></th>
    <th>    <p class="text-center" style = "display:inline;">Message</p></th>
    <th>    <p class="text-center" style = "display:inline;">Link</p></th>
    <th>    <p class="text-center" style = "display:inline;">Image</p></th>
        </div>
    </tr>
<?php
$receiver = $_GET['receiver'];
if(isset($_POST['submit'])) {

  $createdAt = date("Y-m-d h:i:sa");
  $receiver = $_POST['received_by'];
  $message = $_POST['message'];
  $sender=$_SESSION['ID'];
  $sendMessage = "INSERT INTO contactus (sent_by,received_by,message,createdAt) 
                    VALUES('$sender','$receiver','$message','$createdAt')";
  mysqli_query($conn,$sendMessage) or die(mysqli_error($conn));
}
$getMessage = "SELECT  contactus.* ,user.Name FROM contactus INNER JOIN user on sent_by=user.UserID  WHERE received_by = '0' OR sent_by = '0' or sent_by = ".$_SESSION['ID']."  ORDER BY createdAt asc";
$getMessageResult = mysqli_query($conn,$getMessage) or die(mysqli_error($conn));
if(mysqli_num_rows($getMessageResult) > 0) {
    while($getMessageRow = mysqli_fetch_array($getMessageResult)) { 
        ?>
    <tr><div style = "margin: 10;">
    
    <td>    <h4 style = "color: black;display:inline;"><?=$getMessageRow['Name']?></h4></td>
    <td>    <p class="text-center" style = "display:inline;"><?=$getMessageRow['message']?></p></td>
    <td>    <p class="text-center" style = "display:inline;"><?=$getMessageRow['link']?></p></td>
        <?php if(!empty($getMessageRow['Image'])){?>
            <td>    <p class="text-center" style = "display:inline;"><img src=../images/<?php echo $getMessageRow['Image']?> width='100' height='100'></p></td>
        <?php } ?>
        </div>
        </tr>
<?php } 
} 
else { 
    echo "<tr><td><p>How Can We Help You!!</p></td></tr>";
}
?>
</table>
<form class= action="" method = "POST" enctype='multipart/form-data'>
    <input type="hidden" name = "sent_by" value = "<?=$_SESSION['ID']?>"/>
    <input type="hidden" name = "received_by" value = "<?=$receiver?>"/>
    <textarea name = "message" rows="4" cols="100" maxlength="100" size="20" placeholder = "Type your message here" required/></textarea><br>
    <input type = "submit" value='send' name='submit' class="btn btn-default">
    <input type="button" value="Cancel" onclick="cancel()" class="btn btn-default"></input>
</form>
<script>
  function cancel() {
            window.location.href = "AuditorHome.php";
        }
        function fileValidation() {
            var fileInput = 
                document.getElementById('file');
              
            var filePath = fileInput.value;
            var allowedExtensions = 
                    /(\.jpg|\.jpeg|\.png|\.gif)$/i;
              
            if (!allowedExtensions.exec(filePath)) {
                alert('Invalid file type');
                fileInput.value = '';
                return false;
            } 
            else 
            {
                if (fileInput.files && fileInput.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        document.getElementById(
                            'imagePreview').innerHTML = 
                            '<img src="' + e.target.result
                            + '"/>';
                    };
                      
                    reader.readAsDataURL(fileInput.files[0]);
                }
            }
        }
</script>
