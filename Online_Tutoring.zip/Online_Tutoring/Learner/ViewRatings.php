<?php
include "LearnerMenu.php";
?>
<style>
    table th{
        padding: 10px;
        text-align: center;
    }
    table td{
        padding: 10px;
        text-align: center;
    }
</style>
<table  class="table table-light">
  <thead class="thead-dark">
    <tr>
        <th>Count</th>
        <th>Rating</th>
    </tr>

<?php
$conn = new mysqli("localhost", "root", "", "online_tutoringdb");
    if($conn->connect_error)
    die("cannot connect database");
    $sql="SELECT rating ,COUNT(*) As count  FROM review WHERE courseID=".$_GET["id"]." GROUP BY rating";
    $result = mysqli_query($conn,$sql);	
    while($row=mysqli_fetch_array($result)){
?>
    <tr>
    <td><?php echo $row['count'] ?></td>
    <td><?php echo $row['rating'] ?></td>
    </tr>
<?php } ?>
    </thead>
</table>