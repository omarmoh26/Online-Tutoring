<html>
	<?php include "../links.html"; 
	session_start();
	function Avg_Rating($cid){
		$conn = new mysqli("localhost", "root", "", "online_tutoringdb");
		if($conn->connect_error)
			die("cannot connect database");
		$sql="SELECT ROUND (AVG(rating),2) AS average FROM review WHERE courseID=".$cid ;
		$result = mysqli_query($conn,$sql);	
		
		if($row=mysqli_fetch_array($result)){
			 if($row["average"]==0)
				 echo "No Ratings yet";
			 else
				 echo $row["average"];
		}
		$conn->close();
	}
	?>
	
<head>
	<style>
		
	body {
	background: linear-gradient(132deg, #0892d0,#fc6c85 , #6050dc);
	background-size: 400% 400%;
	animation: Gradient 15s ease infinite;
	position: relative;
	height: 100vh;
	width: 100%;
	overflow: hidden;
	padding:0;
	margin:0px;
	}
	@keyframes Gradient {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}
	.topnav ul{
		list-style-type: none;
		color: blue;
		margin: 0;
  		padding: 0;
		overflow: hidden;
		font-size: 25px;
	}
	.topnav ul li {
		float: left;
	}
	.topnav li a {
		display: inline-block;
		color: darkred;
		text-align: center;
		padding: 14px 16px;
		font-family: 'Oswald', sans-serif;
		text-decoration: none;
	}
	.topnav i{
		display: block;
		margin-left: auto;
		margin-right: auto;
	}
	.topnav n{
		
		width:120px;
		font-size: 20px;
		font-weight: 600;
		position:fixed;
		right:0;
		top:10;
		/* height:10; */
		/* z-index:2; */
	 }
	 .topnav n1{
		 
		 width:120px;
		 font-size: 20px;
		 font-weight: 600;
		 position:fixed;
		 top:2;
		 right:55;
		 /* z-index:2; 
		 height:100vh; */
	  }
	.circular
	{
		border-radius: 50%;
	}
	
	.topnav li a:hover{
		background-color: gold;
		color: navy;
	}
	table th{
        padding: 10px;
        text-align: center;
    }
    table td{
        padding: 10px;
        text-align: center;
    }
	
	</style>
	<link rel="stylesheet" type="text/css" href ="LearnerSearch.css">

<script>
	function validateInput(field){
		if(field=='')
			return 'Enter Course name or CourseID \n';
		else
			return '';
	}
	function validate(form){
		fail='';
		fail+=validateInput(form.course.value);
		if(fail=='')
			return true;
		else{
			alert(fail);
			return false;
		}
	}
</script>
</head>

	<body>		
		<div class="topnav">
		<div class="search-box">

<form action="" method="post" onsubmit='return validate(this)'>
	<button type="submit" name="submitsearch" class="btn-search"><i class="fas fa-search"></i></button>
	<input type="text" name="course" class="input-search" placeholder="Type to Search...">
</form>

  </div>
	<?php
		if(!empty($_SESSION['ID'])) 
		{
			echo "<i><img src=../images/EGLearn.png alt='Italian Trulli' width='329.5' height='78.39'></i>";
			echo "<n><b>".$_SESSION['Name']."</b></n>";
			echo "<n1><img class='circular' src=../images/".$_SESSION["Image"]." alt='Italian Trulli' width='50' height='50' class><br></n1>";
			echo"<ul>";
			echo"<li><a href='LearnerHome.php'> Home </a></li>";
			echo"<li><a href='CoursesLearner.php'> Courses </a> </li>";
			echo"<li><a href='LearnerAccount.php'> Account </a> </li>";
			echo"<li><a href='MessagesLearner.php'> Messages </a> </li>";
			echo"<li><a href='Cart.php'> View Cart </a> </li>";
			echo"<li><a href='ContactUsMessage.php'> Contact Us </a> </li>";
			echo "</ul>";
		}
		if(isset($_POST['submitsearch'])){
				
			$search_value=$_POST["course"];
			$conn = new mysqli("localhost", "root", "", "online_tutoringdb");
			$sql="SELECT * FROM courses WHERE courseCode ='$search_value' OR courseName ='$search_value'";
			$result = mysqli_query($conn,$sql);	
			if($row=mysqli_fetch_array($result))
			{
				$_SESSION["courseID"]=$row["CourseID"];
				$_SESSION["courseCode"]=$row["courseCode"];
				$_SESSION['courseName']=$row["courseName"];
				$_SESSION['courseDuration']=$row["courseDuration"];
				$_SESSION['coursePrice']=$row["coursePrice"];
				?>
				<table  class="table table-light">
					<thead class="thead-dark">
					
						<tr>
						<th>Course Image</th>
						<th>Course Code</th>
						<th>Course Name</th>
						<th>Course Duration</th>
						<th>Course Price</th>
						<th>Reviews</th>
						<th>Average Rating</th>
						<th>Add Review</th>
						</tr>
				
						<tr>
						<td><img src=../images/<?php echo $row['Image']?> alt='Italian Trulli' width='100' height='100'> </td>
						<td><?php echo $row['courseCode'] ?></td>
						<td><?php echo $row['courseName'] ?></td>
						<td><?php echo $row['courseDuration']." Months" ?></td>
						<td><?php echo $row['coursePrice']." $" ?></td>
						<td> <a href=ViewReviews.php?id=<?php echo $row['CourseID'] ?>> View Reviews</a> </td>
						<td> <a href=ViewRatings.php?id=<?php echo $row['CourseID'] ?>><?php echo Avg_Rating ($row['CourseID']) ?> </a></td>
						<td> <a href=AddReview.php?id=<?php echo $row['CourseID'] ?>> Add Reviews</a> </td>
						</tr>
			<?php
			}
			else	
			{
				echo "Enter Correct Course name or CourseID";
			}   
		}
		?>
	
		<br><br>
		</div>
	</body>

</html>