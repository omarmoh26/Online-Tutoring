<html>
<?php 
include "BasicMenu.php";
$conn = new mysqli("localhost", "root", "", "online_tutoringdb");
$oldpasserror=" ";
$newpasserror=" ";

if(isset($_POST['submit'])){
	$i=$_SESSION['ID'];
	
	$oldp=$_POST['oldpass'];
	$newp=$_POST['confirm_password'];
	
	$sanitizedoldp=filter_var($oldp,FILTER_SANITIZE_STRING);
	$sanitizednewp=filter_var($newp,FILTER_SANITIZE_STRING);
	$type=$_SESSION['usertype'];
	
	if($sanitizedoldp==$_SESSION['Password']){
		if($sanitizednewp!=$sanitizedoldp){
			$sql="update user set Password='$sanitizednewp' where UserID='$i'";
			$result=mysqli_query($conn,$sql);
			
			if(!$result){
				die("Unable to excute query");
			}
			else{
				$_SESSION["Password"]=$sanitizednewp;
				header("Location:LearnerHome.php");
			}
		}
		else{
			$newpasserror="<h1 style='color:red;'>Please enter a new password</h1>";
		}
	}
	else{
		$oldpasserror="<h1 style='color:red;'>Please Enter the correct Old Password</h1>";
	}
	
}

?>
<link rel="stylesheet" type="text/css" href ="EditPassLearner.css">

<div class="wrapper fadeInDown">
	<div id="formContent">
	  <?php echo $oldpasserror; ?>
		<form action='' method='POST'  onsubmit='return validate(this)'>

		<input type= 'Password'  name= 'oldpass'  placeholder='Old Password' >

		<input name="password" id="password" type="password" placeholder='New Password' onkeyup='check();' />

		<input type="password" name="confirm_password" id="confirm_password" placeholder='Confirm Password' onkeyup='check();' /> 

		<br><span id='message'></span>

		<br><span id = "verifymessage" style="color:red"> </span> <br>

		<input type= 'submit'  name= 'submit'  value= 'Submit' >

		<input type="button" value="Cancel" onclick="cancel()"></input>

		</form>
	</div>
</div>		
<head>
	<script>
		function cancel() {
            window.location.href = "LearnerHome.php";
        }
		var check = function() {
			if (document.getElementById('password').value ==
				document.getElementById('confirm_password').value) {
				document.getElementById('message').style.color = 'green';
				document.getElementById('message').innerHTML = 'matching';
			} 
			else {
				document.getElementById('message').style.color = 'red';
				document.getElementById('message').innerHTML = 'not matching';
			}
		}
		function validateoldPass(field){
			if(field=='')
				return 'Enter old password \n';
			else
				return '';
		}
		function validatenewPass(field){
			if(field=='')
				return 'Enter new password \n';
			else
				return '';
		}function validateconfirmnewPass(field){
			if(field=='')
				return 'Enter Confirm password \n';
			else
				return '';
		}
		
		function validate(form){
			fail='';
			fail+=validateoldPass(form.oldpass.value);
			fail+=validatenewPass(form.password.value);
			fail+=validateconfirmnewPass(form.confirm_password.value);
			if(fail==''){
				pw=form.confirm_password.value;   
				if(pw.length < 8) {  
					 document.getElementById("verifymessage").innerHTML = "*Password length must be atleast 8 characters*";  
					 return false;  
				 }  
				if(pw.length > 15) {  
					 document.getElementById("verifymessage").innerHTML = "*Password length must not exceed 15 characters*";  
					 return false;  
				} 
				else {  
					 return true;
				}  
					
			}
				
			else{
				alert(fail);
				return false;
			}
			
		}
	</script>
</head>
</html>