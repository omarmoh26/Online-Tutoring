<html>
<link rel="stylesheet" type="text/css" href ="DeleteAdminLearner.css">

<?php 
    include "AdminHome.php"; 
    if(isset($_POST['submit'])){
        $id=$_POST["id"];
        $conn = new mysqli("localhost","root","","online_tutoringdb");
        if($conn->connect_error)    
            die("cannot connect database");

        $query ="delete from user where UserID='$id'";
        
        $results= $conn->query($query);
        
        if (!$results)
            die("fatal error in executing query");
        else {
            header("Location:TutorsView.php");
        }
    }
?>

<div class="wrapper fadeInDown">
    <div id="formContent">
        <h2 id="sign" class="active">Are you sure you want to remove this Tutor ?</h2>
        <form action="" method="post" >
            <?php
            $conn = new mysqli("localhost","root","","online_tutoringdb");
            
            if($conn->connect_error)
                die("cannot connect database");

            $query ="SELECT * FROM user where Type='tutor' and UserID=".$_GET["id"] ;
            
            $results= $conn->query($query);
            
            if (!$results)
                die("fatal error in executing query");
            
                while($row=$results->fetch_array(MYSQLI_ASSOC)){?>
                    <img src=../images/<?php echo $row['Image']?> alt='Italian Trulli' width='100' height='100'>
                    <input type="hidden" name="id" value= <?php echo $row['UserID']?> readonly>
                    <input  type="text" name="name"  value=<?php echo $row['Name']?> readonly>
                    <input type="text" name="email" value=<?php echo $row['Email']?> readonly>
                    <input type="text" name="password" placeholder="Password" value=<?php echo $row['Password']?> readonly>  
                    <input type="text" name="type" value=<?php echo $row["Type"]?> readonly><br>";
                <?php 
                }
            ?>
            <input type="submit" value="Delete tutor" name="submit">
            <input type="button" value="Cancel" onclick="cancel()"></input>

        </form>
    </div>
</div>              
	<script>
        function cancel() {
            window.location.href = "TutorsView.php";
        }
	</script>
</html>
