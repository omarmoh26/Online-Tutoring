<link rel="stylesheet" type="text/css" href ="ContactUsMessages.css">

<?php
include "../links.html";
include "AdminMenu.php";
$conn = new mysqli("localhost", "root", "", "online_tutoringdb");

 
?>

<form class="form-inline" method = "POST" action = "">
    <input type="text" name = "name" placeholder="Search" class="form-control">
    <input type="submit" value='Search' name='search' class="btn btn-default">
</form>
<?php
if(isset($_POST['search'])) {
    $search=$_POST['name'];
    $searchUser = "SELECT * FROM user WHERE Name = '$search'";
    $searchUserResult = mysqli_query($conn,$searchUser);

    while($searchUserRow = mysqli_fetch_array($searchUserResult)){  ?>
        <div class="nav">
        <img src = "../images/<?=$searchUserRow['Image']?>" class="img-circle" width='80' height='80'/>
        <n><br><?=$searchUserRow['Name']?>
        <a href="ContactUsMessage.php?receiver=<?=$searchUserRow['UserID']?>">Send message</a></n>
        </div>
<?php }
}
?>
<div>
<?php
$lastMessage = "SELECT DISTINCT sent_by FROM contactus WHERE received_by = '0'";
$lastMessageResult = mysqli_query($conn,$lastMessage) or die(mysqli_error($conn));
if(mysqli_num_rows($lastMessageResult) > 0) {
    while($lastMessageRow = mysqli_fetch_array($lastMessageResult)) {
        $sent_by = $lastMessageRow['sent_by'];
        $getSender = "SELECT * FROM user WHERE user.UserID = '$sent_by'";
        $getSenderResult = mysqli_query($conn,$getSender) or die(mysqli_error($conn));
        $getSenderRow = mysqli_fetch_array($getSenderResult);
        ?>
        <div class="nav">
        <img src = "../images/<?=$getSenderRow['Image']?>" class="img-circle" width='80' height='80'/> 
        <n><br><?=$getSenderRow['Name'];?>
        <a href="ContactUsMessage.php?receiver=<?=$sent_by?>">Send message</a></n>
        </div><br>
<?php }
} 
else {
    echo "No conversations yet!";
}
?>
</div>

