<html>
<?php
include "AdminMenu.php";
?>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  /* color: blue; */
  /* overflow: hidden; */
  font-size: 20px;
}

li a {
  display: block;
  color: darkred;
  padding: 14px 16px;
  font-family: 'Oswald', sans-serif;
  /* text-decoration: none; */
}

li a:hover {
	background-color: gold;
	color: navy;
}
</style>

<ul>
	<li><a href='EditNameAdmin.php'> Edit Name </a></li>
	<li><a href='EditPicAdmin.php'> Edit Picture </a></li>
    <li><a href='EditPassAdmin.php'> Edit Password </a></li>
	<li><a href='DeleteAccountAdmin.php'> Delete </a></li>
	<li><a href='../SignOut.php'> SignOut </a></li>
</html>