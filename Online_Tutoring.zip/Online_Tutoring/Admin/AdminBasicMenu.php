<html>
	<?php 
	include "../links.html"; 
		session_start();
	?>
<head>
	<style>
		
		body {
	background: linear-gradient(132deg, #0892d0,#fc6c85 , #6050dc);
	background-size: 400% 400%;
	animation: Gradient 15s ease infinite;
	position: relative;
	height: 100vh;
	width: 100%;
	overflow: hidden;
	padding:0;
	margin:0px;
	}
	@keyframes Gradient {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}
	.topnav ul{
		list-style-type: none;
		color: blue;
		margin: 0;
  		padding: 0;
		overflow: hidden;
		font-size: 25px;
	}
	.topnav ul li {
		float: left;
	}
	.topnav li a {
		display: inline-block;
		color: darkred;
		text-align: center;
		padding: 14px 16px;
		font-family: 'Oswald', sans-serif;
		text-decoration: none;
	}
	.topnav i{
		display: block;
		margin-left: auto;
		margin-right: auto;
	}
	.topnav n{
		
	   width:120px;
	   height:100vh;
	   font-size: 20px;
	   	font-weight: 600;
	   position:fixed;
	   right:0;
	   top:10;
	   z-index:2;
    }
	.topnav n1{
		
		width:120px;
		height:100vh;
		font-size: 20px;
		font-weight: 600;
		position:fixed;
		right:0;
		top:2;
		right:55;
		z-index:2;
	 }
	.circular
	{
		border-radius: 50%;
	}
	
	.topnav li a:hover{
		background-color: gold;
		color: navy;
	}
	
	</style>
</head>
	
	<body>		
		<div class="topnav">
			<?php
				if(!empty($_SESSION['ID'])) 
				{
					echo "<i><img src=../images/EGLearn.png alt='Italian Trulli' width='329.5' height='78.39'></i>";
					echo "<n><b>".$_SESSION['Name']."</b></n>";
					echo "<n1><img class='circular' src=../images/".$_SESSION["Image"]." alt='Italian Trulli' width='50' height='50'><br></n1>";
                    echo"<ul>";
					echo"<li><a href='AdminAccount.php'> Account </a> </li>";
					echo"<li><a href='OtherAdmins.php'> Admins </a> </li>";
					echo"<li><a href='LearnersView.php'> Learners </a> </li>";
					echo"<li><a href='AdminOrders.php'> Orders </a> </li>";
					echo"<li><a href='AdminCourses.php'> Courses </a> </li>";
					echo"<li><a href='AdminHome.php'> Home </a></li>";
                    echo "</ul>";
				}
				?>
	
		<br><br>
		</div>
	</body>
</html>